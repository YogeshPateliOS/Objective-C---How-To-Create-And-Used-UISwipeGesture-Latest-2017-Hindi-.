//
//  ViewController.h
//  swipe
//
//  Created by Yogesh Patel on 19/08/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (strong, nonatomic) IBOutlet UILabel *lbl;
@property (strong, nonatomic)UISwipeGestureRecognizer *left;
@property (strong, nonatomic)UISwipeGestureRecognizer *right;
@property (strong, nonatomic)UISwipeGestureRecognizer *up;
@property (strong, nonatomic)UISwipeGestureRecognizer *down;
@end

